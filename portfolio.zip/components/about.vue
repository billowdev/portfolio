<template>
	<section class="about section" id="about">
			<h2 class="section_title">About Me</h2>
			<span class="section_subtitle">My introduction</span>

			<div class="about_container container grid">
				<img src="assets/images/profile_l.webp" alt="" class="about_img">

				<div class="about_data">
					<p class="about_description">
						Proficient in web development, good programming in Python, and other languages such as Java, C#, C++ Knowledge of databases and websites development with HTML, CSS, JavaScript, PHP, and frameworks such as Django, Vue.js, Angular, and React library.
					</p>
					<div class="about_info">
						<div>
							<span class="about_info-title">-</span>
							<span class="about_info-name">Years <br> experience</span>
						</div>

						<div>
							<span class="about_info-title">05+</span>
							<span class="about_info-name">Completed <br> project</span>
						</div>

						<div>
							<span class="about_info-title">-</span>
							<span class="about_info-name">Companies <br> worked</span>
						</div>
					</div>

					<div class="about_buttons">
						<a href="#certificates" class="button button--flex">
							Certificates<i class="uil uil-arrow-down button_icon"></i>
						</a>
					</div>
				</div>
			</div>
		</section>

</template>

<script>
module.exports = {};
</script>

<style>
</style>
