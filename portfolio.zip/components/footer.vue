<template>
  <footer class="footer">
	  <div class="footer_bg">
		  <div class="footer_container container grid">
			  <div>
				  <h1 class="footer_title">lacakp</h1>
				  <span class="footer_subtitle">Akkarapon Phikulsri</span>
			  </div>

			  <ul class="footer_links">
				  <li>
					  <a href="#services" class="footer_link">Services</a>
				  </li>
				  <li>
					  <a href="#portfolio" class="footer_link">Portfolio</a>
				  </li>
				  <li>
					  <a href="#contact" class="footer_link">Contact</a>
				  </li>
			  </ul>

			  <div class="footer_socials">
			
				  <a href="https://www.linkedin.com/in/lacakira/" target="_blank" class="footer_social">
					  <i class="uil uil-linkedin"></i>
				  </a>

				  <a href="https://www.github.com/lacakira" target="_blank" class="footer_social">
					  <i class="uil uil-github"></i>
				  </a>
			  </div>
		  </div>

		  <p class="footer_copy" style="color: #fff">Copyright © 2022 All Rights Reserved by lacakp</p>
	  </div>
  </footer>
</template>

<script>
module.exports = {

}
</script>

<style>

</style>
