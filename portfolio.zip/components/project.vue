<template>
	<section class="project section">
		<div class="project_bg">
			<div class="project_container container grid">
				<div class="project_data">
					<h2 class="project_title">You have a new project?</h2>
					<p class="project_description">Contact Me Now!</p>
					<a href="#contact" class="button button--flex button--white">
						Contact Me<i class="uil uil-message project_icon button_icon"></i>
					</a>
				</div>
			</div>
			<img src="../assets/images/profile_lacakp.png" alt="" class="project_img">
		</div>
	</section>
</template>

<script>
module.exports = {};
</script>

<style>

</style>